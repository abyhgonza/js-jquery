// JavaScript Document for index.html

function cambiarPagina(page){
    $.mobile.changePage("#" + page, {
        transition: "flip"
    });
}//func

var hoteles =[];

$(document).ready(function(){
    
    var latlngInicial = new google.maps.LatLng(36.174968, -115.137222); //Las Vegas, Nevada
    var marcador;
    var latitud;
    var longitud;

    $("#btnGestionarHotel").click(function(){
        cambiarPagina("paginaRegistrarHotel");
        mostrarMapa();
    });
	
	$("#btnRegistrarHotel").click(function(){
            registrarHotel(latitud,longitud);
        });

    $("#btnListarHotel").click(function(){
        cambiarPagina("paginaListarHotel");
        listarHoteles();
    });
	
	$(".btnVolver1").click(function(){
        cambiarPagina("paginaInicio");
        $("#noInfo").remove();
    });
	
	$(".btnVolver2").click(function(){
		cambiarPagina("paginaListarHotel");
	});

    function listarHoteles(){
        $("#hoteles").empty();
        var item = "";
		
        if (hoteles.length == 0){
                item = '<label id="noInfo">"No hay data disponible"</label>';
            } else {
                for(var i = 0; i < hoteles.length; i++){  
                    var hotels = "";
                        hotels += '<a href="#" class="ui-btn ui-icon-location ui-btn-icon-right" onclick="onInfoHotel('+"'"+ hoteles[i].nombre +"'"+')">';
						hotels += '<h3>'+ hoteles[i].nombre +'</h3>';
						hotels += '</a>';

                        item += "<li>"+ hotels +"</li>";
                    }//for
            	}    

        $("#hoteles").listview("refresh");                    
        $("#hoteles").append(item);
    }//func

    function mostrarMapa(){
        var opciones = {
            zoom: 13,
            center: latlngInicial,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        };
    
        var mapa = new google.maps.Map(document.getElementById("divMapa"), opciones);

        marcador = new google.maps.Marker({
            position: latlngInicial,
            map: mapa,
            draggable: true,
            title: "Mi Punto"
        });

        google.maps.event.addListener(marcador, "dragend", function(e){
            latitud = e.latLng.lat();
            longitud = e.latLng.lng();

        });
	}//func

    function registrarHotel(latitud,longitud){
		//input variables
        var nombre = $("#nombre").val();
        var ciudad = $("#ciudad").val();
        var telefono = $("#telefono").val();
        var estrellas = $("#estrellas").val();
		
        var latitud = latitud;
        var longitud = longitud;

        var hotel = {
            nombre: nombre,
            ciudad: ciudad,
            telefono: telefono,
            estrellas: estrellas,
            latitud: latitud,
            longitud: longitud
        };//obj
		
		if($.trim(nombre)=="" || $.trim(ciudad)=="" || $.trim(telefono)=="" || $.trim(estrellas)==""){
			alert("Favor completar todos los campos!!");
			$("#nombre").focus();
		} else {
			hoteles.push(hotel);
			alert("Hotel registrado!!");
            limpiarCampos();
		}
	}//func

   function limpiarCampos() {
        $("#nombre").val("");
        $("#ciudad").val("");
        $("#telefono").val("");
        $("#estrellas").val("");
    }//func

});//main

function onInfoHotel(hotel){
    cambiarPagina("hotel");
    var $hotel = hotel;
    var datos = "";

    for (var i = 0; i < hoteles.length; i++){
		
        if($hotel == hoteles[i].nombre){
			
            datos += "Nombre: "+ hoteles[i].nombre +"<br>";
			datos += "Ciudad: "+ hoteles[i].ciudad +"<br>";
			datos += "Teléfono: "+ hoteles[i].telefono +"<br>";
            datos += "Estrellas: "+ hoteles[i].estrellas +"<br><br>";
			datos += "Ubicación:";
            
            var opciones = {
                zoom: 13,
                center: new google.maps.LatLng(hoteles[i].latitud, hoteles[i].longitud),
                mapTypeId: google.maps.MapTypeId.ROADMAP
            };
        
            var mapa = new google.maps.Map(document.getElementById("mostrarMapa"), opciones);
            latlngInicial = new google.maps.LatLng(hoteles[i].latitud, hoteles[i].longitud);

            marcador = new google.maps.Marker({
                position: latlngInicial,
                map: mapa,
                title: hoteles[i].nombre
            });

            $("#datos").html(datos);
        }
    }//for
}//func